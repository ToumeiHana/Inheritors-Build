# [\[Hero-Variant\] \[M\] Armored by Nuramon](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FInfantry%20-%20(Swd)%20Mercenaries%20and%20Heroes%2F%5BHero-Variant%5D%20%5BM%5D%20Armored%20by%20Nuramon%2F3.%20Axe)

## Axe

| Still | Animation |
| :---: | :-------: |
| ![Axe still](./Axe_000.png) | ![Axe](./Axe.gif) |

## Credit

Animation by Nuramon.

Spinning Handaxe by Sax-Marine.
