# [\[Mercenary-Reskin\] \[F\] Generic v2 by TBA](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FInfantry%20-%20(Swd)%20Mercenaries%20and%20Heroes%2F%5BMercenary-Reskin%5D%20%5BF%5D%20Generic%20v2%20by%20TBA%2F8.%20Unarmed)

## Unarmed

| Still | Animation |
| :---: | :-------: |
| ![Unarmed still](./Unarmed_000.png) | ![Unarmed](./Unarmed.gif) |

## Credit

Vanilla FE8 Mercenary Male animation by IS.

Female variant by TheBlindArcher. 

Edit by Knabepicer.
