How to use:

Create a txt file with your text formatted according to CrazyColorz's text parser.
At the top of the file, add a line with the text ID.

NarrowFont:
* is used for the narrow serif font and ^ is used for the narrow menu font.
In order from lowest priority to highest priority:

Write text as *{text} or ^{text} to use the narrow font only for what’s inside the curly brackets. These brackets must be on the same line.
Put a * or a ^ at the end of the first line for a text entry to use the narrow font for the whole text ID.
Put a {* or a {^ instead to begin using the narrow font for this whole text ID and every text ID after.
Put a } instead to stop using the narrow font. (Note that it will still use the narrow font for the whole text ID you put the } on.)
