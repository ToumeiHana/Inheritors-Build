#ifndef GUARD_GBA_GBA_H
#define GUARD_GBA_GBA_H

#include "types.h"
#include "defines.h"
#include "ioreg.h"
#include "syscall.h"
#include "macro.h"

#endif // GUARD_GBA_GBA_H
