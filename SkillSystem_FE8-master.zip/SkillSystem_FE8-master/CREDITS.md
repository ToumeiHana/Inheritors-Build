Note: This list is incomplete and insufficiently organized. If you contributed
something that you'd like special recognition for, please make a pull request
adding yourself!

# Skill contributors

- Tequila
- Rossendale
- StanH
- Leonarth
- 2WB
- Teraspark
- Darrman
- SD9k
- Kao
- blademaster
- Snakey1
- Zeta
- Kirb
- Sme
- Ganzap
- Mikey Seregon

# Other

- 7743: various bugfixes
- RobertFPY, Pikmin1211, and Snakey1: Str/Mag Split Finalization

# Icons

- Monkeybard, Black Mage
- Blaze: Stances
- vlak: Drives
- Pikmin1211: Miscellaneous
- 2WB: Miscellaneous
- Zaim: Indoor March
- Reds: Quick Riposte

